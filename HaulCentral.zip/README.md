# HaulCentral
A modern trucking load board built with React and Vite.